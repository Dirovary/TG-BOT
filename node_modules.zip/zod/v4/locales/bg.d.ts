import type * as errors from "../core/errors.js";
export declare const parsedType: (data: any) => string;
export default function (): {
    localeError: errors.$ZodErrorMap;
};
