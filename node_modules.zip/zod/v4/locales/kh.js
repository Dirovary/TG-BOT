import km from "./km.js";
/** @deprecated Use `km` instead. */
export default function () {
    return km();
}
