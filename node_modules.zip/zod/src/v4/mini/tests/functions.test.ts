import { expect, test } from "vitest";

test("z.function", () => {
  expect(true).toEqual(true);
});
